export const POSES=[
{id:'up',name:'雙手高舉',en:'REACH UP',color:'#a2f2d4',key:'1',arms:[[-.26,-.62],[-.36,-.95],[.26,-.62],[.36,-.95]]},
{id:'spread',name:'水平展開',en:'OPEN WIDE',color:'#9bd5f1',key:'2',arms:[[-.47,-.38],[-.78,-.38],[.47,-.38],[.78,-.38]]},
{id:'left',name:'左手舉高',en:'LEFT RISE',color:'#c4b8f5',key:'3',arms:[[-.26,-.62],[-.36,-.95],[.3,-.12],[.36,.1]]},
{id:'right',name:'右手舉高',en:'RIGHT RISE',color:'#f7b18e',key:'4',arms:[[-.3,-.12],[-.36,.1],[.26,-.62],[.36,-.95]]},
{id:'cross',name:'胸前交叉',en:'CROSS ARMS',color:'#f0d68d',key:'5',arms:[[-.28,-.05],[.19,-.38],[.28,-.05],[-.19,-.38]]}
];
export const TRACKS={
 orbit:{name:'ORBIT',desc:'深空電子',style:'ambient',bpm:108,root:46,beats:80},
 flux:{name:'FLUX',desc:'液態氛圍',style:'ambient',bpm:96,root:41,beats:80},
 nova:{name:'NOVA',desc:'能量電子',style:'electro',bpm:128,root:48,beats:96},
 reactor:{name:'REACTOR',desc:'工業 Techno',style:'techno',bpm:140,root:42,beats:112},
 breakline:{name:'BREAKLINE',desc:'Drum & Bass',style:'dnb',bpm:168,root:38,beats:128},
 concrete:{name:'CONCRETE',desc:'重拍 Hip-hop',style:'hiphop',bpm:94,root:43,beats:80},
 velocity:{name:'VELOCITY',desc:'律動 Funk',style:'funk',bpm:120,root:45,beats:96},
 neon:{name:'NEON DRIVE',desc:'復古 Synthwave',style:'synthwave',bpm:112,root:45,beats:96}
};
export const DISTANCE_ZONES={far:{name:'遠',color:'#a18bff'},mid:{name:'中',color:'#39dfff'},near:{name:'近',color:'#ffbd4a'},hit:{name:'命中窗',color:'#83ffb5'}};
export function distanceZone(delta){return Math.abs(delta)<=.22?'hit':delta<=.85?'near':delta<=2.2?'mid':'far';}
export {evaluatePose} from './precision.js';
export const WINDOWS={perfect:.100,good:.220};
export function makeChart(track,difficulty='easy'){
 const step=difficulty==='normal'?2:4;
 const pattern=[0,1,2,3,4,1,0,3,2,4,0,1,4,2,3,1,0,4,3,2,1,4,0,2,3,4,1,3,0,2,4,1,2,0,3,1,4,0,2,3,4,1,0,3,2,4];
 let i=0;const notes=[];for(let beat=4;beat<track.beats;beat+=step)notes.push({id:i,pose:POSES[pattern[i++%pattern.length]].id,time:beat*60/track.bpm,status:'pending'});return notes;
}
export class Session{
 constructor(track=TRACKS.orbit,difficulty='easy'){this.track=track;this.notes=makeChart(track,difficulty);this.score=0;this.combo=0;this.maxCombo=0;this.perfect=0;this.good=0;this.miss=0;this.poseSamples=[];this.duration=(track.beats+4)*60/track.bpm;}
 hit(pose,time,{poseAccuracy=100,source='keyboard'}={}){if(!Number.isFinite(poseAccuracy)||poseAccuracy<78)return null;const note=this.notes.filter(n=>n.status==='pending'&&n.pose===pose&&Math.abs(n.time-time)<=WINDOWS.good+1e-8).sort((a,b)=>Math.abs(a.time-time)-Math.abs(b.time-time))[0];if(!note)return null;const delta=time-note.time;note.status=Math.abs(delta)<=WINDOWS.perfect+1e-8&&poseAccuracy>=90?'perfect':'good';this[note.status]++;this.combo++;this.maxCombo=Math.max(this.combo,this.maxCombo);const points=(note.status==='perfect'?1000:600)+Math.min(this.combo-1,20)*20;this.score+=points;note.poseAccuracy=poseAccuracy;note.source=source;if(source==='camera')this.poseSamples.push(poseAccuracy);return {note,grade:note.status,delta,points,poseAccuracy,source};}
 update(time){const missed=[];for(const n of this.notes){if(n.status==='pending'&&time>n.time+WINDOWS.good){n.status='miss';this.miss++;this.combo=0;missed.push(n);}}return missed;}
 get accuracy(){const total=this.perfect+this.good+this.miss;return total?Math.round((this.perfect+this.good*.6)/total*100):null;}
 get poseAccuracy(){return this.poseSamples.length?Math.round(this.poseSamples.reduce((a,b)=>a+b,0)/this.poseSamples.length):null;}
 get completed(){return this.perfect+this.good+this.miss;}
 get rank(){const a=this.accuracy||0;return a>=95?'S':a>=80?'A':a>=60?'B':a>=40?'C':'D';}
}
export function classifyPose(p){
 if(!p||p.length<29)return {pose:null,confidence:0};
 const ids=[11,12,13,14,15,16,23,24];const confidence=Math.min(...ids.map(i=>p[i]?.visibility??0));
 if(confidence<.6||ids.some(i=>!Number.isFinite(p[i]?.x)||!Number.isFinite(p[i]?.y)||p[i].x<.01||p[i].x>.99||p[i].y<.01||p[i].y>.99))return {pose:null,confidence};
 const [ls,rs,le,re,l,r,lh,rh]=ids.map(i=>p[i]);
 const sy=(ls.y+rs.y)/2,hy=(lh.y+rh.y)/2,torso=hy-sy,sw=Math.abs(ls.x-rs.x);
 if(torso<.07||sw<.055)return {pose:null,confidence};
 const lu=l.y<ls.y-torso*.5&&le.y<ls.y+.07*torso,ru=r.y<rs.y-torso*.5&&re.y<rs.y+.07*torso;
 const ld=l.y>sy+torso*.48,rd=r.y>sy+torso*.48;
 let pose=null;
 if(lu&&ru)pose='up';
 else if(lu&&rd)pose='left';
 else if(ru&&ld)pose='right';
 else if((l.x-r.x)*(ls.x-rs.x)<0&&Math.abs(l.x-r.x)>sw*.2&&Math.abs(l.y-sy)<torso*.58&&Math.abs(r.y-sy)<torso*.58)pose='cross';
 else if(Math.abs(l.y-ls.y)<torso*.25&&Math.abs(r.y-rs.y)<torso*.25&&Math.abs(l.x-r.x)>sw*2.15&&Math.abs(le.y-sy)<torso*.25&&Math.abs(re.y-sy)<torso*.25)pose='spread';
 return {pose,confidence};
}
