import {POSES} from './engine.js';
import {drawHuman} from './visuals.js';
export function recordingFormat(){
 if(typeof MediaRecorder==='undefined')return null;
 return ['video/mp4;codecs=avc1.42E01E,mp4a.40.2','video/mp4','video/webm;codecs=vp8,opus','video/webm'].find(t=>MediaRecorder.isTypeSupported(t))||null;
}
export function clipBounds(start,end,duration){
 const max=Math.max(.1,Number.isFinite(duration)?duration:.1);
 start=Math.max(0,Math.min(max-.1,Number(start)||0));
 end=Math.max(start+.1,Math.min(max,Number(end)||max));
 return {start,end};
}
// MediaRecorder WebM often omits Duration. Patch only the simple streaming
// layout (unknown Segment size, no SeekHead), leaving every media frame intact.
export async function withDuration(blob,seconds){
 if(!blob.type.includes('webm'))return blob;
 const a=new Uint8Array(await blob.arrayBuffer());
 const vint=(pos,id=false)=>{if(pos>=a.length||a[pos]===0)return null;let n=1,mask=128;while(!(a[pos]&mask)&&n<8){mask>>=1;n++;}if(pos+n>a.length)return null;let value=id?a[pos]:a[pos]&(mask-1);for(let i=1;i<n;i++)value=value*256+a[pos+i];return {n,value,unknown:!id&&Array.from(a.slice(pos,pos+n)).every((b,i)=>b===(i===0?mask*2-1:255))};};
 const read=pos=>{const id=vint(pos,true);if(!id)return null;const size=vint(pos+id.n);if(!size)return null;return {id:id.value,size,at:pos+id.n,start:pos+id.n+size.n,end:pos+id.n+size.n+size.value};};
 let pos=0,segment;while(pos<a.length){const e=read(pos);if(!e)break;if(e.id===0x18538067){segment=e;break;}pos=e.end;}
 if(!segment?.size.unknown)return blob;pos=segment.start;let info;
 while(pos<a.length){const e=read(pos);if(!e)break;if(e.id===0x114d9b74)return blob;if(e.id===0x1549a966){info=e;break;}if(e.id===0x1f43b675)break;pos=e.end;}
 if(!info||info.end>a.length)return blob;
 let scale=1000000;pos=info.start;
 while(pos<info.end){const e=read(pos);if(!e)break;if(e.id===0x4489)return blob;if(e.id===0x2ad7b1){scale=0;for(const b of a.slice(e.start,e.end))scale=scale*256+b;}pos=e.end;}
 const extra=new Uint8Array(11);extra.set([0x44,0x89,0x88]);new DataView(extra.buffer).setFloat64(3,seconds*1e9/scale);
 const length=info.size.value+extra.length,n=info.size.n;if(length>=2**(7*n)-1)return blob;
 const result=new Uint8Array(a.length+11);result.set(a.slice(0,info.end));result.set(extra,info.end);result.set(a.slice(info.end),info.end+11);
 let remaining=length;for(let i=n-1;i>=0;i--){result[info.at+i]=remaining%256;remaining=Math.floor(remaining/256);}result[info.at]|=1<<(8-n);
 return new Blob([result],{type:blob.type});
}
export class MovementStudio{
 constructor({onStatus,onReady}){
  this.canvas=document.createElement('canvas');this.canvas.width=1280;this.canvas.height=720;this.c=this.canvas.getContext('2d');this.onStatus=onStatus;this.onReady=onReady;this.recorder=null;this.active=false;this.finishing=null;this.blob=null;this.url=null;this.duration=0;this.highlights=[];this.photoUrls=[];this.exporting=false;
 }
 draw({field,video,landmarks,session,elapsed,state,playerPose,precision,feedback}){
  const c=this.c;c.fillStyle='#07141a';c.fillRect(0,0,1280,720);
  c.fillStyle='#a2f2d4';c.font='bold 25px sans-serif';c.fillText('GRAVITY / SYNC',30,43);c.font='13px monospace';c.fillStyle='#c8ded8';c.fillText(`${session.track.name} / ${session.track.desc} / ${session.track.bpm} BPM`,30,69);
  c.fillStyle='#9fb6b4';c.font='12px monospace';c.textAlign='right';c.fillText('YOUR MOVEMENT REPLAY · '+elapsed.toFixed(1)+'s',1245,43);c.textAlign='left';
  c.drawImage(field,24,91,790,533);c.strokeStyle='#375858';c.strokeRect(24,91,790,533);
  c.fillStyle='#0f252b';c.fillRect(842,91,412,533);c.fillStyle='#a2f2d4';c.font='13px sans-serif';c.fillText(video.srcObject?'你的動作 / 真人鏡像':'你的動作 / 鍵盤練習',861,120);
  if(video.srcObject&&video.readyState>=2){
   const ratio=video.videoWidth/video.videoHeight,w=Math.min(390,435*ratio),h=w/ratio,x=853+(390-w)/2,y=140+(435-h)/2;
   c.save();c.translate(x+w,y);c.scale(-1,1);c.drawImage(video,0,0,w,h);c.restore();
   if(landmarks){const at=i=>[x+(1-landmarks[i].x)*w,y+landmarks[i].y*h];c.strokeStyle='#83ffb5';c.lineWidth=3;for(const [a,b]of [[11,12],[11,13],[13,15],[12,14],[14,16],[11,23],[12,24],[23,24],[23,25],[25,27],[24,26],[26,28]]){if(Math.min(landmarks[a]?.visibility||0,landmarks[b]?.visibility||0)<.6)continue;c.beginPath();c.moveTo(...at(a));c.lineTo(...at(b));c.stroke();}}
  }else if(playerPose){drawHuman(c,1048,370,170,playerPose,'#a2f2d4');}
  else{c.fillStyle='#607f7c';c.font='17px sans-serif';c.textAlign='center';c.fillText('跟著拍點，讓身體動起來',1048,340);c.textAlign='left';}
  c.fillStyle='#cceae1';c.font='15px sans-serif';c.fillText(`姿勢 ${precision?.score??'—'}% · ${precision?.hint||'等待動作'}`,861,596,374);
  c.fillStyle='#12282f';c.fillRect(24,642,1230,57);c.fillStyle='#a2f2d4';c.font='bold 21px monospace';c.fillText(`SCORE ${String(session.score).padStart(6,'0')}    COMBO ${session.combo}×    SYNC ${session.accuracy??'—'}%`,43,678);c.textAlign='right';c.font='15px sans-serif';c.fillText(feedback||'MOVE WITH THE FIELD',1235,678);c.textAlign='left';
  if(state==='complete'){
   c.fillStyle='#07141ae8';c.fillRect(120,160,595,345);c.textAlign='center';c.fillStyle='#a2f2d4';c.font='18px monospace';c.fillText('SESSION COMPLETE',418,209);c.font='bold 85px monospace';c.fillText(session.rank,418,311);c.font='23px sans-serif';c.fillText('你與重力，同頻了。',418,363);c.font='16px sans-serif';c.fillText(`${session.score.toLocaleString()} 分 · 最高連擊 ${session.maxCombo}`,418,408);c.fillText(`PERFECT ${session.perfect} / GOOD ${session.good} / MISS ${session.miss}`,418,447);c.textAlign='left';
  }
 }
 start(audioTracks,sessionTime=0){
  const type=recordingFormat();if(!type||!this.canvas.captureStream){this.onStatus('此瀏覽器不支援錄影，可改用 Chrome；遊戲仍可正常進行。');return false;}
  try{
   this.capture=this.canvas.captureStream(24);this.combined=new MediaStream([...this.capture.getVideoTracks(),...audioTracks.map(t=>t.clone())]);
   this.recorder=new MediaRecorder(this.combined,{mimeType:type,videoBitsPerSecond:3500000,audioBitsPerSecond:128000});this.chunks=[];this.highlights=[];this.sessionStartTime=sessionTime;this.active=true;this.started=performance.now();this.pauseMs=0;this.pausedAt=0;
   this.recorder.ondataavailable=e=>{if(e.data.size)this.chunks.push(e.data);};
   this.recorder.onerror=()=>{this.onStatus('錄影失敗，遊戲可繼續。');this.stop().catch(()=>{});};
   this.recorder.start(500);this.onStatus('錄影中 · 遊戲結束後產生動作影片');return true;
  }catch(e){this.active=false;this.combined?.getTracks().forEach(t=>t.stop());this.onStatus('錄影無法啟動，遊戲可繼續。');return false;}
 }
 pause(){if(this.recorder?.state==='recording'){this.pausedAt=performance.now();this.recorder.pause();this.onStatus('錄影暫停 · 休息時間不會放入影片');}}
 resume(){if(this.recorder?.state==='paused'){this.pauseMs+=performance.now()-this.pausedAt;this.pausedAt=0;this.recorder.resume();this.onStatus('錄影中 · 繼續保存你的動作');}}
 mark(hit,elapsed){if(this.active)this.highlights.push({time:Math.max(0,elapsed-this.sessionStartTime),grade:hit.grade,combo:hit.combo});}
 async stop(){
  if(this.finishing)return this.finishing;if(!this.active)return null;
  this.active=false;this.onStatus('正在整理動作影片…');
  const duration=Math.max(.1,(performance.now()-this.started-this.pauseMs-(this.pausedAt?performance.now()-this.pausedAt:0))/1000);
  const recorder=this.recorder;this.finishing=new Promise((resolve,reject)=>{
   const done=async()=>{try{const raw=new Blob(this.chunks,{type:recorder.mimeType});if(raw.size<100)throw new Error('empty recording');const blob=await withDuration(raw,duration);if(this.url)URL.revokeObjectURL(this.url);this.blob=blob;this.url=URL.createObjectURL(blob);this.duration=duration;this.finishing=null;this.onReady({blob,url:this.url,duration,highlights:[...this.highlights]});this.onStatus(`動作影片已完成 · ${duration.toFixed(1)} 秒 · ${(blob.size/1048576).toFixed(1)} MB`);resolve(blob);}catch(e){this.onStatus('影片整理失敗，請重新錄製。');reject(e);}finally{this.combined?.getTracks().forEach(t=>t.stop());this.finishing=null;this.recorder=null;}};
   recorder.onstop=done;if(recorder.state==='inactive')done();else recorder.stop();
  });return this.finishing;
 }
 photo(replay){
  const canvas=document.createElement('canvas');canvas.width=1280;canvas.height=720;canvas.getContext('2d').drawImage(replay?.readyState>=2?replay:this.canvas,0,0,1280,720);
  return new Promise(resolve=>canvas.toBlob(blob=>resolve({blob,url:URL.createObjectURL(blob)}),'image/png'));
 }
 bestClip(){const best=[...this.highlights].sort((a,b)=>b.combo-a.combo)[0];return clipBounds(Math.max(0,(best?.time??this.duration)-7),(best?.time??this.duration)+2,this.duration);}
 async exportClip(start,end,onProgress){
  if(!this.url||this.exporting)throw new Error('影片尚未準備好');this.exporting=true;
  const bounds=clipBounds(start,end,this.duration),v=document.createElement('video');v.src=this.url;v.playsInline=true;v.preload='auto';
  const canvas=document.createElement('canvas');canvas.width=1280;canvas.height=720;const c=canvas.getContext('2d');
  let context,media,recorder,frame,watchdog,stopTimer;const chunks=[];
  try{
   context=new AudioContext();await context.resume();
   await new Promise((resolve,reject)=>{v.oncanplaythrough=resolve;v.onerror=()=>reject(new Error('影片無法讀取'));v.load();});
   if(bounds.start>0){await new Promise(resolve=>{v.onseeked=resolve;v.currentTime=bounds.start;});}
   const dest=context.createMediaStreamDestination(),source=context.createMediaElementSource(v);source.connect(dest);
   c.drawImage(v,0,0,1280,720);media=new MediaStream([...canvas.captureStream(30).getVideoTracks(),...dest.stream.getAudioTracks()]);
   recorder=new MediaRecorder(media,{mimeType:recordingFormat(),videoBitsPerSecond:3500000,audioBitsPerSecond:128000});recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};
   const stopped=new Promise((resolve,reject)=>{recorder.onstop=resolve;recorder.onerror=()=>reject(new Error('片段錄製失敗'));});
   const stop=()=>{v.pause();if(recorder.state!=='inactive')recorder.stop();};
   v.onended=stop;recorder.start();await v.play();
   const draw=()=>{if(recorder.state==='inactive')return;c.drawImage(v,0,0,1280,720);onProgress(Math.min(1,(v.currentTime-bounds.start)/(bounds.end-bounds.start)));if(v.currentTime>=bounds.end-.025)stop();};draw();frame=setInterval(draw,1000/30);stopTimer=setTimeout(stop,(bounds.end-bounds.start)*1000);
   watchdog=setTimeout(stop,(bounds.end-bounds.start+5)*1000);await stopped;
   return await withDuration(new Blob(chunks,{type:recorder.mimeType}),bounds.end-bounds.start);
  }finally{clearTimeout(watchdog);clearTimeout(stopTimer);clearInterval(frame);v.pause();v.removeAttribute('src');v.load();media?.getTracks().forEach(t=>t.stop());await context?.close();this.exporting=false;}
 }
 dispose(){this.recorder?.state!=='inactive'&&this.recorder?.stop();this.combined?.getTracks().forEach(t=>t.stop());if(this.url)URL.revokeObjectURL(this.url);}
}
