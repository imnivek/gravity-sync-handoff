const clamp=n=>Math.max(0,Math.min(1,n));
function angle(a,b,c,aspect){const u=[(a.x-b.x)*aspect,a.y-b.y],v=[(c.x-b.x)*aspect,c.y-b.y];const d=Math.hypot(...u)*Math.hypot(...v);return d?Math.acos(Math.max(-1,Math.min(1,(u[0]*v[0]+u[1]*v[1])/d)))*180/Math.PI:0;}
export function evaluatePose(p,target,aspect=4/3){
 const missing={score:0,valid:false,confidence:0,parts:[],hint:'請讓肩膀、雙手與腰部完整入鏡'};
 if(!p||p.length<29||!target)return missing;
 const ids=[11,12,13,14,15,16,23,24],confidence=Math.min(...ids.map(i=>p[i]?.visibility??0));
 if(confidence<.6||ids.some(i=>!Number.isFinite(p[i]?.x)||!Number.isFinite(p[i]?.y)||p[i].x<.01||p[i].x>.99||p[i].y<.01||p[i].y>.99))return {...missing,confidence};
 const [ls,rs,le,re,lw,rw,lh,rh]=ids.map(i=>p[i]);
 const sy=(ls.y+rs.y)/2,torso=(lh.y+rh.y)/2-sy,sw=Math.abs(ls.x-rs.x);
 if(torso<.07||sw<.055)return {...missing,confidence,hint:'請正面站立，並讓腰部入鏡'};
 const la=angle(ls,le,lw,aspect),ra=angle(rs,re,rw,aspect),parts=[];
 const part=(label,value,hint,detail)=>parts.push({label,score:Math.round(clamp(value)*100),hint,detail});
 const straight=(side,a)=>part(side+'手臂', (a-105)/50,side+'手肘再伸直一些',`${Math.round(a)}° / ≥155°`);
 const raised=(side,s,w)=>part(side+'手高度',(s.y-w.y)/torso/.65,side+'手再抬高，伸到頭頂上方','手腕高於肩膀');
 const down=(side,w)=>part(side+'手高度',(w.y-sy)/torso/.65,side+'手放下，靠近腰側','手腕低於肩膀');
 if(target==='up'){raised('左',ls,lw);raised('右',rs,rw);straight('左',la);straight('右',ra);}
 else if(target==='left'||target==='right'){if(target==='left'){raised('左',ls,lw);down('右',rw);}else{down('左',lw);raised('右',rs,rw);}straight('左',la);straight('右',ra);}
 else if(target==='spread'){
  part('左手水平',1-Math.abs(lw.y-ls.y)/torso/.35,'左手調整到肩膀高度','與肩同高');
  part('右手水平',1-Math.abs(rw.y-rs.y)/torso/.35,'右手調整到肩膀高度','與肩同高');
  straight('左',la);straight('右',ra);
  const span=clamp((Math.abs(lw.x-rw.x)/sw-1.4)/1.2);for(const q of parts.slice(2)){q.score=Math.min(q.score,Math.round(span*100));if(span<.78)q.hint='雙臂再向兩側打開';}
 }else if(target==='cross'){
  const sign=Math.sign(ls.x-rs.x),center=(ls.x+rs.x)/2;
  part('左腕交叉',(center-lw.x)*sign/(sw*.22),'左手跨過胸前中線','雙腕交叉');
  part('右腕交叉',(rw.x-center)*sign/(sw*.22),'右手跨過胸前中線','雙腕交叉');
  part('左手位置',1-Math.abs((lw.y-sy)/torso-.13)/.5,'左手移到胸前','胸前交叉');
  part('右手位置',1-Math.abs((rw.y-sy)/torso-.13)/.5,'右手移到胸前','胸前交叉');
 }
 const score=parts.length?Math.round(parts.reduce((a,b)=>a+b.score,0)/parts.length):0;
 const valid=score>=78&&parts.every(p=>p.score>=55);
 const weakest=[...parts].sort((a,b)=>a.score-b.score)[0];
 return {score,valid,confidence,parts,leftAngle:Math.round(la),rightAngle:Math.round(ra),hint:valid?(score>=90?'姿勢到位，等待綠色拍點':'姿勢合格，再伸展一點更精準'):weakest?.hint||missing.hint};
}
