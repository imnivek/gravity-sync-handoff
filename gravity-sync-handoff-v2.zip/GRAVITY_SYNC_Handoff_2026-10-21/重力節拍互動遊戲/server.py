from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os

os.chdir(Path(__file__).resolve().parent)
class Handler(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map, '.mjs': 'application/javascript', '.js': 'application/javascript', '.wasm': 'application/wasm', '.task': 'application/octet-stream'}
    def end_headers(self):
        self.send_header('Cache-Control', 'no-cache')
        super().end_headers()

if __name__ == '__main__':
    try:
        server = ThreadingHTTPServer(('127.0.0.1', 8876), Handler)
    except OSError as error:
        print(f'重力節拍無法啟動：{error}。若 8876 已被使用，請先關閉之前的伺服器。')
        raise SystemExit(1)
    print('重力節拍：http://127.0.0.1:8876')
    try: server.serve_forever()
    except KeyboardInterrupt: server.server_close()
