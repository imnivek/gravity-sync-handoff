import {POSES,DISTANCE_ZONES,distanceZone} from './engine.js';
const TAU=Math.PI*2;
export function poseSVG(p){const [le,lw,re,rw]=p.arms;const pt=q=>`${40+q[0]*35},${45+q[1]*35}`;return `<svg viewBox="0 0 80 95" aria-hidden="true"><g fill="none" stroke="${p.color}" stroke-width="3.3" stroke-linecap="round" stroke-linejoin="round"><circle cx="40" cy="19" r="6"/><path d="M40 27V53 M31 32H49 M31 32L${pt(le)} ${pt(lw)} M49 32L${pt(re)} ${pt(rw)} M40 53L29 66 25 85 M40 53L51 66 55 85"/></g></svg>`;}
export function drawHuman(c,x,y,size,pose,color,alpha=1){const p=POSES.find(p=>p.id===pose)||POSES[0];c.save();c.translate(x,y);c.scale(size,size);c.globalAlpha=alpha;c.strokeStyle=color||p.color;c.fillStyle=color||p.color;c.lineWidth=.05;c.lineCap='round';c.lineJoin='round';c.shadowColor=color||p.color;c.shadowBlur=12;const path=points=>{points.forEach((q,i)=>i?c.lineTo(...q):c.moveTo(...q));};c.beginPath();c.arc(0,-.81,.10,0,TAU);path([[0,-.68],[0,.02]]);path([[-.16,-.39],[.16,-.39]]);path([[-.16,-.39],p.arms[0],p.arms[1]]);path([[.16,-.39],p.arms[2],p.arms[3]]);path([[0,.02],[-.17,.25],[-.25,.62]]);path([[0,.02],[.17,.25],[.25,.62]]);c.stroke();c.shadowBlur=0;for(const q of [[0,.02],[-.16,-.39],[.16,-.39],...p.arms]){c.beginPath();c.arc(...q,.029,0,TAU);c.fill();}c.restore();}
export class GravityField{
 constructor(canvas){this.canvas=canvas;this.c=canvas.getContext('2d');this.ripples=[];this.mode='ring';this.reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;this.stars=Array.from({length:110},(_,i)=>({x:Math.sin(i*83.1)*.5+.5,y:Math.cos(i*41.7)*.5+.5,size:i%4===0?1.2:.6}));this.resize();new ResizeObserver(()=>this.resize()).observe(canvas);}
 resize(){const rect=this.canvas.getBoundingClientRect();this.w=rect.width;this.h=rect.height;const dpr=Math.min(devicePixelRatio||1,1.25);this.canvas.width=this.w*dpr;this.canvas.height=this.h*dpr;this.c.setTransform(dpr,0,0,dpr,0,0);}
 burst(color){if(this.reduce)return;this.ripples.push({at:performance.now()/1000,color});}
 draw(now,session,elapsed,active,playerPose){const {c,w,h}=this;const t=now/1000,beat=elapsed*session.track.bpm/60,pulse=active?Math.pow(1-(beat%1+1)%1,4):.15;
 c.clearRect(0,0,w,h);const bg=c.createRadialGradient(w*.50,h*.39,10,w*.50,h*.45,w*.8);bg.addColorStop(0,'#163b3d');bg.addColorStop(.35,'#0a252b');bg.addColorStop(1,'#061217');c.fillStyle=bg;c.fillRect(0,0,w,h);
 for(const s of this.stars){c.globalAlpha=.15+s.size*.18;c.fillStyle='#c4ece6';c.beginPath();c.arc(s.x*w,s.y*h,s.size,0,TAU);c.fill();}c.globalAlpha=1;
 const cx=w*.52,vanish=h*.33,ty=h*.76,rx=Math.min(w*.26,205),ry=Math.min(h*.12,64),travel=3.5;
 // Bent field lines make one continuous gravity well toward the hit ring.
 c.lineWidth=.65;for(let j=0;j<36;j++){const a=j/36*TAU;const endX=cx+Math.cos(a)*w*.9,endY=vanish+Math.sin(a)*h*1.1;const grad=c.createLinearGradient(cx,vanish,endX,endY);grad.addColorStop(0,'#79dac700');grad.addColorStop(.4,'#79dac71c');grad.addColorStop(1,'#79dac709');c.strokeStyle=grad;c.beginPath();c.moveTo(cx+Math.cos(a)*9,vanish+Math.sin(a)*4);c.bezierCurveTo(cx+Math.cos(a+.5)*w*.18,vanish+Math.sin(a+.5)*h*.22,cx+Math.cos(a)*w*.36,vanish+Math.sin(a)*h*.46,endX,endY);c.stroke();}
 for(let j=0;j<12;j++){const phase=(j/12+(this.reduce?0:t*.055))%1,z=Math.pow(phase,1.8),y=vanish+(ty-vanish)*z;c.strokeStyle=`rgba(113,206,191,${.045+z*.11})`;c.lineWidth=.7;c.beginPath();c.ellipse(cx,y,10+rx*z,4+ry*z,0,0,TAU);c.stroke();}
 // Floating orbital wave ribbon.
 for(let j=0;j<3;j++){c.beginPath();for(let i=0;i<130;i++){const q=i/129,x=q*w,y=vanish+Math.sin(q*8+(this.reduce?0:t*.3)+j*.3)*(18+j*4)+Math.cos(q*3)*20;i?c.lineTo(x,y):c.moveTo(x,y);}c.strokeStyle=['#85dbc321','#9eb4e519','#85dbc30c'][j];c.lineWidth=1;c.stroke();}
 c.strokeStyle='#9be5d918';c.setLineDash([2,6]);c.beginPath();c.moveTo(cx,vanish);c.lineTo(cx,ty);c.stroke();c.setLineDash([]);
 // Three judgement shapes share the same timeline and hit position.
 c.save();c.shadowColor='#83ffb5';c.shadowBlur=18+pulse*14;c.strokeStyle='#83ffb5';c.lineWidth=2+pulse;
 if(this.mode==='gate'){
  c.fillStyle='#83ffb510';c.fillRect(cx-rx,ty-24,rx*2,48);c.strokeRect(cx-rx,ty-24,rx*2,48);
  c.beginPath();c.moveTo(cx-rx-18,ty);c.lineTo(cx+rx+18,ty);c.stroke();
 }else if(this.mode==='lanes'){
  for(let i=0;i<5;i++){const x=w*(.18+i*.16);c.beginPath();c.ellipse(x,ty,w*.064,20,0,0,TAU);c.stroke();c.font='10px monospace';c.fillStyle='#baffd3';c.textAlign='center';c.fillText(String(i+1),x,ty+38);c.strokeStyle='#83ffb522';c.lineWidth=.7;c.beginPath();c.moveTo(cx,vanish);c.lineTo(x,ty);c.stroke();c.strokeStyle='#83ffb5';c.lineWidth=2;}
 }else{
  c.beginPath();c.ellipse(cx,ty,rx,ry,0,0,TAU);c.stroke();c.shadowBlur=0;c.strokeStyle='#83ffb538';c.lineWidth=1;c.beginPath();c.ellipse(cx,ty,rx+12,ry+7,0,0,TAU);c.stroke();
 }
 c.restore();
 for(const [d,name]of [[2.6,'far'],[1.55,'mid'],[.45,'near']]){
  const z=Math.pow(1-d/travel,1.75),y=vanish+(ty-vanish)*z;c.strokeStyle=DISTANCE_ZONES[name].color+'65';c.lineWidth=1;c.beginPath();c.ellipse(cx,y,10+rx*z,4+ry*z,0,0,TAU);c.stroke();
  if(w>550&&this.mode!=='lanes'){c.font='9px monospace';c.fillStyle=DISTANCE_ZONES[name].color;c.textAlign='left';c.fillText(DISTANCE_ZONES[name].name+' / '+(name==='far'?'READ':name==='mid'?'PREPARE':'MOVE'),cx+rx*z+26,y+3);}
 }
 c.font='8px monospace';c.fillStyle='#7ca19e';c.textAlign='left';c.fillText('− GRAVITY VECTOR',22,h*.52);c.fillText('G / 9.81',22,h*.52+14);c.textAlign='right';c.fillText('SYNC / '+(active?'ACTIVE':'STANDBY'),w-22,h*.52);c.fillText('φ '+(active?(beat%1).toFixed(2):'0.00'),w-22,h*.52+14);
 const notes=active||elapsed>0?session.notes:[{pose:'up',time:.55,status:'pending'},{pose:'spread',time:2.05,status:'pending'},{pose:'left',time:2.95,status:'pending'}];
 for(const n of [...notes].reverse()){
  if(n.status!=='pending')continue;const delta=n.time-elapsed;if(delta>travel||delta<-.3)continue;
  const q=1-delta/travel,z=Math.pow(Math.max(0,q),1.75),y=vanish+(ty-vanish)*z,scale=15+z*73;
  const index=POSES.findIndex(p=>p.id===n.pose),p=POSES[index],zone=DISTANCE_ZONES[distanceZone(delta)],nx=this.mode==='lanes'?cx+(w*(.18+index*.16)-cx)*z:cx;
  const alpha=Math.min(1,.4+q*.65);c.save();c.globalAlpha=alpha*.7;c.strokeStyle=zone.color;c.lineWidth=delta<=.85?2:1;c.beginPath();c.ellipse(nx,y,scale*.8,scale*.18,0,0,TAU);c.stroke();c.restore();
  drawHuman(c,nx,y-scale*.58,scale,n.pose,zone.color,alpha);
  if(delta<2.3){c.fillStyle=zone.color;c.font=(delta<.85?'bold 11px':'10px')+' sans-serif';c.textAlign='center';c.globalAlpha=alpha;const labelY=this.mode==='lanes'?y-scale*1.7:y-scale*.9;c.fillText(p.key+' · '+p.name,this.mode==='lanes'?nx:nx-scale*1.15,labelY);c.globalAlpha=1;}
 }
 if(playerPose)drawHuman(c,cx-rx*.75,ty-5,42,playerPose,'#ffffff',.45);
 if(!this.reduce){this.ripples=this.ripples.filter(r=>t-r.at<1);for(const r of this.ripples){const a=t-r.at;c.strokeStyle=r.color;c.globalAlpha=(1-a)*.6;c.lineWidth=1.5;c.beginPath();c.ellipse(cx,ty,rx+a*w*.65,ry+a*h*.3,0,0,TAU);c.stroke();c.globalAlpha=1;}}
 // Frequency spectrum at the lower edge, tied to the real beat and combo.
 for(let i=0;i<58;i++){const x=w*.17+i*w*.66/58,a=active?5+Math.sin(i*1.7+beat*2)*4+pulse*(10+Math.sin(i)*7)+Math.min(session.combo,15)*.4:3+Math.sin(i*.5+t)*2;c.fillStyle=`rgba(147,225,204,${active?.35:.13})`;c.fillRect(x,h-42,1.5,-a);}
 }
}
