const hz=m=>440*Math.pow(2,(m-69)/12);
export class SoundField{
 constructor(){this.ctx=null;this.muted=false;this.nextStep=0;this.voices=new Set();}
 async unlock(){
  if(!this.ctx){
   this.ctx=new AudioContext();this.master=this.ctx.createGain();this.master.gain.value=.65;
   const comp=this.ctx.createDynamicsCompressor();comp.threshold.value=-18;comp.ratio.value=6;
   this.monitor=this.ctx.createGain();this.monitor.gain.value=this.muted?0:1;
   this.recordBus=this.ctx.createMediaStreamDestination();this.master.connect(comp);comp.connect(this.monitor);this.monitor.connect(this.ctx.destination);comp.connect(this.recordBus);
   this.noise=this.ctx.createBuffer(1,this.ctx.sampleRate*.35,this.ctx.sampleRate);const a=this.noise.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=Math.random()*2-1;
  }
  await this.ctx.resume();
 }
 tone(freq,time,duration,type='sine',volume=.1,slide=null,cutoff=0){
  const o=this.ctx.createOscillator(),g=this.ctx.createGain();o.type=type;o.frequency.setValueAtTime(freq,time);if(slide)o.frequency.exponentialRampToValueAtTime(slide,time+duration);
  g.gain.setValueAtTime(.0001,time);g.gain.exponentialRampToValueAtTime(volume,time+.005);g.gain.exponentialRampToValueAtTime(.0001,time+duration);
  let f;if(cutoff){f=this.ctx.createBiquadFilter();f.type='lowpass';f.frequency.setValueAtTime(cutoff,time);f.frequency.exponentialRampToValueAtTime(Math.max(110,cutoff*.25),time+duration);o.connect(f);f.connect(g);}else o.connect(g);
  g.connect(this.master);o.start(time);o.stop(time+duration+.02);this.voices.add(o);o.onended=()=>{this.voices.delete(o);o.disconnect();g.disconnect();f?.disconnect();};
 }
 noiseHit(time,volume=.05,duration=.075,filter='highpass',freq=6500){
  const n=this.ctx.createBufferSource(),g=this.ctx.createGain(),f=this.ctx.createBiquadFilter();n.buffer=this.noise;f.type=filter;f.frequency.value=freq;
  g.gain.setValueAtTime(volume,time);g.gain.exponentialRampToValueAtTime(.0001,time+duration);n.connect(f);f.connect(g);g.connect(this.master);n.start(time);n.stop(time+duration+.01);this.voices.add(n);n.onended=()=>{this.voices.delete(n);n.disconnect();f.disconnect();g.disconnect();};
 }
 kick(t,v=.6){this.tone(165,t,.26,'sine',v,43);this.noiseHit(t,.045,.016,'lowpass',1400);}
 snare(t,v=.26){this.noiseHit(t,v,.15,'bandpass',2300);this.tone(180,t,.09,'triangle',v*.45,100);}
 play(track,elapsed=0){this.stop();this.track=track;this.origin=this.ctx.currentTime-elapsed;this.nextStep=Math.ceil(elapsed/(60/track.bpm/4));this.playing=true;this.schedule();this.timer=setInterval(()=>this.schedule(),25);}
 schedule(){
  if(!this.playing)return;const beat=60/this.track.bpm,style=this.track.style;
  while(this.origin+this.nextStep*beat/4<this.ctx.currentTime+.12){
   const step=this.nextStep++,t=this.origin+step*beat/4;if(t<this.ctx.currentTime||step>=(this.track.beats+4)*4)continue;
   const bar=step%16,section=Math.floor(step/64)%4,base=this.track.root+[0,-3,5,-5][section];
   if(style==='dnb'){
    if([0,6,10,14].includes(bar))this.kick(t,.5);if([4,12].includes(bar))this.snare(t,.35);
    this.noiseHit(t,bar%2?.035:.075,.04);if([0,3,6,8,10,14].includes(bar))this.tone(hz(base-12+(bar>=8?7:0)),t,beat*.5,'sawtooth',.16,null,700);
    if(bar%4===2)this.tone(hz(base+24+[0,3,7,10][Math.floor(bar/4)]),t,beat*.35,'square',.045,null,1800);
   }else if(style==='hiphop'){
    if([0,3,8,10].includes(bar))this.kick(t,.65);if([4,12].includes(bar))this.snare(t,.29);
    if(bar%2===0||bar===15)this.noiseHit(t,bar===15?.07:.035,.05);
    if([0,3,8,10].includes(bar))this.tone(hz(base-12+(bar===10?7:0)),t,beat*.8,'sine',.28);
    if(bar===2||bar===10)for(const n of [0,3,7,10])this.tone(hz(base+n+12),t,beat*.8,'triangle',.032);
   }else if(style==='funk'){
    if([0,6,8,11].includes(bar))this.kick(t,.47);if([4,12].includes(bar))this.snare(t,.25);
    this.noiseHit(t,bar%2?.03:.06,.045);
    const riff={0:0,3:7,6:10,8:12,10:7,11:5,14:3};if(bar in riff)this.tone(hz(base-12+riff[bar]),t,beat*.28,'triangle',.25,null,1400);
    if([2,7,10,15].includes(bar))for(const n of [0,4,7])this.tone(hz(base+n+12),t,beat*.16,'sawtooth',.036,null,2400);
   }else if(style==='techno'){
    if(bar%4===0)this.kick(t,.65);if([4,12].includes(bar))this.snare(t,.18);
    if(bar%4===2)this.noiseHit(t,.12,.1);else if(bar%2)this.noiseHit(t,.024,.025);
    if(bar%2)this.tone(hz(base-12),t,beat*.24,'sawtooth',.23,null,600);
    const notes=[0,0,7,0,3,0,10,7];if(bar%2===0)this.tone(hz(base+notes[bar/2]+12),t,beat*.17,'square',.063,null,1900+(section*300));
   }else{
    if(bar%4===0)this.kick(t,style==='ambient'?.36:.54);if([4,12].includes(bar))this.snare(t,style==='ambient'?.14:.26);
    if(bar%2===0)this.noiseHit(t,bar%4===2?.07:.035,.05);
    if(bar%4===0)this.tone(hz(base-12),t,beat*.7,style==='synthwave'?'sawtooth':'triangle',.19,null,900);
    if(bar%2===0){const arp=[0,7,12,15,12,7,10,7][bar/2];this.tone(hz(base+arp+12),t,beat*.52,style==='ambient'?'sine':'triangle',.075);}
    if(bar===0)for(const n of [0,7,12])this.tone(hz(base+n+12),t,beat*3.5,style==='synthwave'?'sawtooth':'sine',.035,null,1500);
   }
  }
 }
 get elapsed(){return this.ctx?this.ctx.currentTime-this.origin:0;}
 get recordingTracks(){return this.recordBus?.stream.getAudioTracks()||[];}
 stop(){this.playing=false;clearInterval(this.timer);for(const o of this.voices){try{o.stop();}catch{}}this.voices.clear();}
 setMuted(value){this.muted=value;if(this.ctx)this.monitor.gain.setTargetAtTime(value?0:1,this.ctx.currentTime,.03);}
 hit(){if(this.ctx)this.tone(hz(88),this.ctx.currentTime,.1,'sine',.025,hz(95));}
}
