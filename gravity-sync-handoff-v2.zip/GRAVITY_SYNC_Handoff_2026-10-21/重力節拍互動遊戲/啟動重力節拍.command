#!/bin/zsh
cd "${0:A:h}"
/usr/bin/python3 server.py &
game_server_pid=$!
trap 'kill "$game_server_pid" 2>/dev/null' EXIT INT TERM
sleep 1
if ! kill -0 "$game_server_pid" 2>/dev/null; then
  echo '啟動失敗，請先關閉先前的伺服器。'; exit 1
fi
open 'http://127.0.0.1:8876'
echo '關閉此視窗或按 Ctrl+C 即可停止遊戲。'
wait "$game_server_pid"
