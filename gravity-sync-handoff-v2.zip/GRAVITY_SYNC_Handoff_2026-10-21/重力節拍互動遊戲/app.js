import {POSES,TRACKS,Session,classifyPose,evaluatePose} from './engine.js';
import {SoundField} from './audio.js';
import {GravityField,poseSVG,drawHuman} from './visuals.js';
import {MovementStudio,clipBounds,recordingFormat} from './media.js';
const $=id=>document.getElementById(id);
const sound=new SoundField(),field=new GravityField($('field'));
let difficulty='easy',session=new Session(),state='idle',starting=false,elapsed=0,feedbackUntil=0,feedbackText='',held=null,heldUntil=0;
let stream=null,worker=null,cameraReady=false,busy=false,cameraGeneration=0,lastFrame=0,lastPoseAt=0,landmarks=null,livePose=null,candidate=null,candidateSince=0,cameraStarting=false;
let precision=null,lastComposite=0,endingTimer=null,clipUrl=null,clipPreviewEnd=null,photoCount=0,lastRender=0,inferenceMs=0,roundToken=0;
const labels={idle:'待機 · 等待你的第一個節拍',running:'紫 → 藍 → 橙 → 綠 · 綠色拍點做出動作',paused:'已暫停 · 準備好再繼續',complete:'本場完成 · 你的動作影片正在下方等待'};
const studio=new MovementStudio({onStatus:message=>{$('record-status').textContent=message;recordIndicator();},onReady:ready=>{
 if(clipUrl){URL.revokeObjectURL(clipUrl);clipUrl=null;}$('download-clip').classList.add('hidden');$('replay').src=ready.url;$('replay-empty').classList.add('hidden');$('download-video').href=ready.url;$('download-video').download=fileName('full',ready.blob);$('download-video').classList.remove('disabled');$('download-video').setAttribute('aria-disabled','false');
 for(const id of ['clip-start','clip-end']){$(id).max=ready.duration.toFixed(3);$(id).disabled=false;}
 $('clip-start').value=0;$('clip-end').value=ready.duration;updateClip();for(const id of ['best-clip','preview-clip','export-clip'])$(id).disabled=false;controls();
}});
$('poses').innerHTML=POSES.map(p=>`<button class="pose-card" data-pose="${p.id}" aria-label="${p.name}，鍵盤 ${p.key}">${poseSVG(p)}<span><strong>${p.name}</strong><small>${p.en}</small></span><kbd>${p.key}</kbd></button>`).join('');
function fileName(kind,blob){return `gravity-sync-${kind}-${Date.now()}.${blob.type.includes('mp4')?'mp4':blob.type.includes('png')?'png':'webm'}`;}
function timeString(t){return `${String(Math.floor(t/60)).padStart(2,'0')}:${String(Math.floor(t%60)).padStart(2,'0')}`;}
function stats(){ $('score').textContent=String(session.score).padStart(6,'0');$('combo').innerHTML=`${session.combo}<span>×</span>`;$('accuracy').innerHTML=`${session.accuracy??'—'}<span>%</span>`;}
function recordIndicator(){const r=studio.recorder?.state;$('record-indicator').textContent=r==='recording'?'● REC':r==='paused'?'Ⅱ PAUSED':studio.finishing?'SAVING':'READY';$('record-indicator').classList.toggle('recording',r==='recording');$('manual-record').textContent=studio.active?'■ 停止錄影':'● 開始錄影';$('manual-record').disabled=!['running','paused'].includes(state)||!!studio.finishing;}
function controls(){
 const playing=state==='running'||state==='paused';document.body.classList.toggle('playing',playing);$('start').disabled=state==='running';$('start').innerHTML=state==='paused'?'繼續同步 <span>↗</span>':state==='complete'?'再來一場 <span>↗</span>':'進入重力場 <span>↗</span>';
 $('pause').disabled=!playing;$('reset').disabled=state==='idle';$('pause').textContent=state==='paused'?'▷ 繼續':'Ⅱ 暫停';$('track').disabled=playing;$('auto-record').disabled=playing||!recordingFormat();
 document.querySelectorAll('[data-difficulty]').forEach(b=>b.disabled=playing);$('stage-state').textContent=labels[state];$('view-replay').disabled=!studio.url&&!!studio.finishing;
 for(const id of ['clip-start','clip-end','best-clip','preview-clip','export-clip'])$(id).disabled=playing||!studio.url||studio.exporting;
 recordIndicator();
}
function reset(stopRecording=true){
 roundToken++;clearTimeout(endingTimer);if(stopRecording)studio.stop().catch(()=>{});sound.stop();state='idle';elapsed=0;session=new Session(TRACKS[$('track').value],difficulty);$('result').classList.add('hidden');$('feedback').textContent='';$('countdown').textContent='';$('target-name').textContent='綠色拍點，做出相同動作';$('bpm-display').textContent=`${session.track.bpm} BPM`;$('track-desc').textContent=`${session.track.desc} · ${session.track.bpm} BPM`;held=null;feedbackText='';precision=null;controls();stats();
}
async function start(){
 if(starting)return;if(studio.exporting){$('record-status').textContent='片段正在匯出，完成後即可開始下一場。';return;}starting=true;
 try{
  $('start').disabled=true;$('replay').pause();await sound.unlock();
  if(state!=='paused'){clearTimeout(endingTimer);await studio.stop().catch(()=>{});reset(false);state='running';sound.play(session.track,elapsed);compose();if($('auto-record').checked)studio.start(sound.recordingTracks,state==='running'?sound.elapsed:elapsed);}
  else{state='running';sound.play(session.track,elapsed);studio.resume();}
  $('result').classList.add('hidden');controls();const stage=document.querySelector('.stage');if(innerWidth<=720||stage.getBoundingClientRect().top<0)stage.scrollIntoView({block:'start',behavior:'instant'});
 }catch(e){state='idle';controls();$('stage-state').textContent='音訊啟動失敗，請重新按開始';console.error(e);}finally{starting=false;}
}
function pause(){if(state==='running'){elapsed=sound.elapsed;sound.stop();studio.pause();state='paused';$('countdown').textContent='Ⅱ';held=null;controls();}else if(state==='paused')start();}
function finish(){
 sound.stop();state='complete';elapsed=session.duration;$('countdown').textContent='';$('result-rank').textContent=session.rank;
 $('result-detail').textContent=`${session.score.toLocaleString()} 分 · 同步率 ${session.accuracy??0}% · 最高連擊 ${session.maxCombo}\nPERFECT ${session.perfect} / GOOD ${session.good} / MISS ${session.miss}${session.poseAccuracy===null?'':` · 平均姿勢 ${session.poseAccuracy}%`}`;
 $('result').classList.remove('hidden');controls();compose();endingTimer=setTimeout(()=>studio.stop().catch(()=>{}),1100);
}
function notify(hit){
 field.burst('#83ffb5');sound.hit();studio.mark({...hit,combo:session.combo},hit.note.time+hit.delta);
 const ms=Math.round(hit.delta*1000),timing=Math.abs(ms)<10?'正拍':`${ms<0?'早':'晚'} ${Math.abs(ms)} ms`;
 feedbackText=`${hit.grade.toUpperCase()} · ${timing}`;$('timing-detail').textContent=timing;$('feedback').style.color=hit.grade==='perfect'?'#83ffb5':'#ffbd4a';
 $('feedback').innerHTML=`${hit.grade.toUpperCase()}<small>+${hit.points} · ${hit.source==='camera'?`姿勢 ${hit.poseAccuracy}% · `:'鍵盤 · '}${timing}</small>`;feedbackUntil=performance.now()+750;stats();
}
function attempt(pose){if(stream||cameraStarting)return;held=pose;heldUntil=performance.now()+300;if(state==='running'){const hit=session.hit(pose,sound.elapsed);if(hit)notify(hit);else{$('feedback').style.color='#97aaa9';$('feedback').innerHTML='跟上拍點<small>人形轉綠時，再做動作</small>';feedbackUntil=performance.now()+420;}}else field.burst(POSES.find(p=>p.id===pose).color);}
function nextTarget(){return session.notes.find(n=>n.status==='pending')?.pose||'up';}
function updatePrecision(now){
 const target=nextTarget(),name=POSES.find(p=>p.id===target).name;
 precision=stream&&now-lastPoseAt<450?evaluatePose(landmarks,target,($('camera-video').videoWidth||640)/($('camera-video').videoHeight||480)):null;
 $('diagnostic-target').textContent='目標：'+name;$('diagnostic-score').textContent=precision?`${precision.score}%`:'—%';$('pose-accuracy').textContent=precision?`${precision.score}%`:'—';
 $('match-progress').style.width=(precision?.score||0)+'%';$('match-progress').style.background=precision?.valid?'#83ffb5':'#ffbd4a';
 $('pose-hint').textContent=precision?.hint||(stream?'正在等待清楚的身體追蹤':'啟用鏡頭後，顯示動作角度與修正提示');
 $('angle-detail').textContent=precision?.leftAngle!==undefined?`左肘 ${precision.leftAngle}° · 右肘 ${precision.rightAngle}° · 追蹤 ${Math.round(precision.confidence*100)}% · ${Math.round(inferenceMs)}ms`:'左肘 —° · 右肘 —°';
}
function drawSkeleton(){
 const canvas=$('skeleton'),c=canvas.getContext('2d'),v=$('camera-video'),mode=$('recognition-view').value,w=canvas.clientWidth,h=canvas.clientHeight;canvas.width=w*2;canvas.height=h*2;c.scale(2,2);document.querySelector('.camera-preview').className='camera-preview view-'+mode;
 if(!landmarks)return;
 if(mode==='radar'){
  const cx=w/2,cy=h/2-4,r=Math.min(w*.27,h*.35);const parts=precision?.parts||[];
  for(let layer=1;layer<=3;layer++){c.strokeStyle='#496c6855';c.beginPath();for(let i=0;i<=4;i++){const a=i*Math.PI/2-Math.PI/2,x=cx+Math.cos(a)*r*layer/3,y=cy+Math.sin(a)*r*layer/3;i?c.lineTo(x,y):c.moveTo(x,y);}c.stroke();}
  c.beginPath();for(let i=0;i<=4;i++){const q=parts[i%4],a=i*Math.PI/2-Math.PI/2,s=(q?.score||0)/100;const x=cx+Math.cos(a)*r*s,y=cy+Math.sin(a)*r*s;i?c.lineTo(x,y):c.moveTo(x,y);}c.fillStyle='#83ffb538';c.fill();c.strokeStyle='#83ffb5';c.stroke();c.font='8px sans-serif';c.fillStyle='#bdd7d0';c.textAlign='center';parts.forEach((q,i)=>{const a=i*Math.PI/2-Math.PI/2;c.fillText(q.label+' '+q.score,cx+Math.cos(a)*(r+17),cy+Math.sin(a)*(r+12));});return;
 }
 const ratio=(v.videoWidth||640)/(v.videoHeight||480),vw=Math.min(w,h*ratio),vh=vw/ratio,ox=(w-vw)/2,oy=(h-vh)/2;const p=i=>({x:ox+(1-landmarks[i].x)*vw,y:oy+landmarks[i].y*vh});
 if(mode==='overlay'&&landmarks[23]&&landmarks[11]){const chest={x:(p(11).x+p(12).x)/2,y:(p(11).y+p(12).y)/2},hip={y:(p(23).y+p(24).y)/2};const size=Math.max(15,(hip.y-chest.y)/.41);c.setLineDash([.05,.05]);drawHuman(c,chest.x,chest.y+size*.39,size,nextTarget(),'#ffbd4a',.32);c.setLineDash([]);}
 c.strokeStyle=precision?.valid?'#83ffb5':'#39dfff';c.lineWidth=2;
 for(const [a,b]of [[11,12],[11,13],[13,15],[12,14],[14,16],[11,23],[12,24],[23,24],[23,25],[25,27],[24,26],[26,28]]){if((landmarks[a].visibility??0)<.5||(landmarks[b].visibility??0)<.5)continue;c.beginPath();c.moveTo(p(a).x,p(a).y);c.lineTo(p(b).x,p(b).y);c.stroke();}
 c.fillStyle='#e8fff7';for(const i of [0,11,12,13,14,15,16,23,24,25,26,27,28]){if((landmarks[i].visibility??0)<.5)continue;c.beginPath();c.arc(p(i).x,p(i).y,2,0,Math.PI*2);c.fill();}
}
function recognitionView(){drawSkeleton();if(cameraReady)$('camera-status').textContent={overlay:'橙色疊影為目標；綠色骨架代表姿勢合格。',radar:'四軸顯示各部位符合度，向外延伸代表更到位。',mirror:'鏡像左右與你一致；查看下方角度與修正提示。'}[$('recognition-view').value];}
function stopCamera(message='影像只在你的電腦處理，不會上傳。'){
 cameraGeneration++;cameraStarting=false;cameraReady=false;busy=false;worker?.terminate();worker=null;stream?.getTracks().forEach(t=>t.stop());stream=null;landmarks=null;livePose=null;candidate=null;lastPoseAt=0;precision=null;$('camera-video').srcObject=null;$('camera-placeholder').classList.remove('hidden');$('camera-toggle').textContent='◎ 啟用鏡頭辨識';$('camera-toggle').disabled=false;$('camera-status').textContent=message;$('camera-quality').textContent='';$('input-mode').textContent='鍵盤練習';$('mode-footer').textContent='鍵盤練習模式';drawSkeleton();
}
async function startCamera(){
 if(stream||cameraStarting){stopCamera();return;}const generation=++cameraGeneration;cameraStarting=true;$('camera-toggle').disabled=true;$('camera-toggle').textContent='正在連接鏡頭…';$('camera-status').textContent='請在瀏覽器允許鏡頭，模型由本機載入。';
 try{
  if(!navigator.mediaDevices?.getUserMedia)throw new Error('unsupported');const acquired=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:640},height:{ideal:480},facingMode:'user'},audio:false});
  if(generation!==cameraGeneration){acquired.getTracks().forEach(t=>t.stop());return;}stream=acquired;const video=$('camera-video');video.srcObject=stream;await video.play();if(generation!==cameraGeneration)return;
  $('camera-placeholder').classList.add('hidden');$('camera-toggle').textContent='× 關閉鏡頭';$('camera-toggle').disabled=false;$('camera-status').textContent='正在載入姿態模型…';worker=new Worker('pose-worker.js');
  worker.onmessage=({data})=>{
   if(generation!==cameraGeneration)return;
   if(data.type==='ready'){cameraReady=true;cameraStarting=false;$('input-mode').textContent='身體同步';$('mode-footer').textContent='鏡頭姿態辨識模式';recognitionView();}
   else if(data.type==='pose'){busy=false;landmarks=data.landmarks;lastPoseAt=data.timestamp;inferenceMs=data.ms;const result=classifyPose(landmarks);if(candidate!==result.pose){candidate=result.pose;candidateSince=data.timestamp;}livePose=candidate&&lastPoseAt-candidateSince>=65?candidate:null;$('camera-quality').textContent=result.confidence>=.6?(livePose?POSES.find(p=>p.id===livePose).name:'身體已連線 · 等待動作'):'請讓雙手與腰部完整入鏡';updatePrecision(performance.now());drawSkeleton();if(state==='running'&&livePose&&Number.isFinite(data.sampleTime)&&data.roundToken===roundToken&&performance.now()-data.timestamp<450){const note=session.notes.find(n=>n.status==='pending'&&n.pose===livePose&&data.sampleTime>=n.time&&data.sampleTime<=n.time+.22);const match=evaluatePose(landmarks,livePose,(video.videoWidth||640)/(video.videoHeight||480));if(note&&match.valid){const hit=session.hit(livePose,data.sampleTime,{poseAccuracy:match.score,source:'camera'});if(hit)notify(hit);}}}
   else if(data.type==='error')stopCamera('姿態模型無法載入。可先用鍵盤練習，再重新連線。');
  };
  worker.onerror=()=>stopCamera('鏡頭辨識中斷。可先用鍵盤練習，再重新連線。');worker.postMessage({type:'init',delegate:'GPU'});
 }catch(e){if(generation!==cameraGeneration)return;const messages={NotAllowedError:'未允許鏡頭。可使用鍵盤，或允許鏡頭後重新連線。',NotFoundError:'找不到鏡頭，可使用鍵盤或動作卡練習。',NotReadableError:'鏡頭正被其他程式使用，請關閉後再連線。'};stopCamera(messages[e.name]||'無法啟用鏡頭，請用本機啟動器開啟，或先使用鍵盤練習。');}
}
async function sendFrame(now){
 if(!cameraReady||busy||now-lastFrame<50||document.hidden||studio.exporting)return;const v=$('camera-video');if(v.readyState<2)return;lastFrame=now;busy=true;const generation=cameraGeneration;
 try{const ratio=(v.videoWidth||640)/(v.videoHeight||480),sampleTime=state==='running'?sound.elapsed:null;const bitmap=await createImageBitmap(v,{resizeWidth:320,resizeHeight:Math.round(320/ratio),resizeQuality:'low'});if(generation!==cameraGeneration||!worker){bitmap.close();return;}worker.postMessage({type:'frame',bitmap,timestamp:now,sampleTime,roundToken},[bitmap]);}catch{busy=false;}
}
function compose(){studio.draw({field:$('field'),video:$('camera-video'),landmarks,session,elapsed,state,playerPose:stream?livePose:held,precision,feedback:performance.now()<feedbackUntil?feedbackText:''});}
function render(now){
 if(now-lastRender<(state==='running'?33:50)){requestAnimationFrame(render);return;}lastRender=now;
 if(studio.exporting){requestAnimationFrame(render);return;}
 updatePrecision(now);
 if(state==='running'){
  elapsed=sound.elapsed;const beat=60/session.track.bpm,lead=4*beat-elapsed;$('countdown').textContent=lead>0?Math.ceil(lead/beat):'';
  const next=session.notes.find(n=>n.status==='pending');
  if(livePose&&precision?.valid&&now-lastPoseAt<350&&next?.pose===livePose&&elapsed>=next.time&&elapsed<=next.time+.22){const hit=session.hit(livePose,elapsed,{poseAccuracy:precision.score,source:'camera'});if(hit)notify(hit);}
  const misses=session.update(elapsed-(stream ? .45 : 0));if(misses.length){$('feedback').style.color='#97aaa9';$('feedback').innerHTML=`MISS<small>${stream&&!precision?.valid?'姿勢還差一點 · 查看修正提示':'拍點晚了 · 下一拍重新同步'}</small>`;feedbackText='MISS';feedbackUntil=now+650;stats();}
  if(elapsed>=session.duration)finish();const target=session.notes.find(n=>n.status==='pending');$('target-name').textContent=target?POSES.find(p=>p.id===target.pose).name:'最後的節拍，正在回響';
 }
 if(now>heldUntil)held=null;const current=now-lastPoseAt<300?livePose:null;field.draw(now,session,elapsed,state==='running'||state==='paused',stream?current:held);
 document.querySelectorAll('[data-pose]').forEach(b=>b.classList.toggle('active',b.dataset.pose===(stream?current:held)));
 $('feedback').style.opacity=now<feedbackUntil?'1':'0';$('clock').innerHTML=`${timeString(elapsed)} <em>/ ${timeString(session.duration)}</em>`;$('progress').style.width=`${Math.min(100,elapsed/session.duration*100)}%`;
 if(studio.active&&now-lastComposite>=42){compose();lastComposite=now;}requestAnimationFrame(render);
}
function updateClip(changed){
 let a=Number($('clip-start').value),b=Number($('clip-end').value);
 if(changed==='start'&&a>=b)b=Math.min(studio.duration,a+.1);if(changed==='end'&&b<=a)a=Math.max(0,b-.1);
 const bounds=clipBounds(a,b,studio.duration);$('clip-start').value=bounds.start;$('clip-end').value=bounds.end;
 $('clip-start-label').textContent=bounds.start.toFixed(1)+'s';$('clip-end-label').textContent=bounds.end.toFixed(1)+'s';return bounds;
}
$('start').addEventListener('click',start);$('pause').addEventListener('click',pause);$('reset').addEventListener('click',()=>reset());$('again').addEventListener('click',start);$('dismiss-result').addEventListener('click',()=>reset());$('track').addEventListener('change',()=>reset());
document.querySelectorAll('[data-difficulty]').forEach(b=>b.addEventListener('click',()=>{difficulty=b.dataset.difficulty;document.querySelectorAll('[data-difficulty]').forEach(x=>{x.classList.toggle('selected',x===b);x.setAttribute('aria-pressed',String(x===b));});reset();}));
document.querySelectorAll('[data-pose]').forEach(b=>b.addEventListener('click',()=>attempt(b.dataset.pose)));
$('sound').addEventListener('click',()=>{sound.setMuted(!sound.muted);$('sound').textContent=sound.muted?'♫ 聲音關':'♫ 聲音開';$('sound').setAttribute('aria-pressed',String(sound.muted));});
$('manual-record').addEventListener('click',async()=>{if(studio.active)await studio.stop().catch(()=>{});else{await sound.unlock();compose();studio.start(sound.recordingTracks,state==='running'?sound.elapsed:elapsed);if(state==='paused')studio.pause();}controls();});$('quick-photo').addEventListener('click',()=>$('photo').click());$('camera-toggle').addEventListener('click',startCamera);$('field-view').addEventListener('change',()=>field.mode=$('field-view').value);$('recognition-view').addEventListener('change',recognitionView);
async function fullscreen(){try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{$('stage-state').textContent='此瀏覽器無法進入全螢幕';}}
$('fullscreen').addEventListener('click',fullscreen);$('help').addEventListener('click',()=>{if(state==='running')pause();$('help-dialog').showModal();});$('close-help').addEventListener('click',()=>$('help-dialog').close());$('reduced-motion').checked=field.reduce;$('reduced-motion').addEventListener('change',e=>field.reduce=e.target.checked);
$('view-replay').addEventListener('click',()=>{if(!studio.url){$('record-status').textContent=studio.finishing?'影片正在整理，稍後即可回放。':'本場沒有錄影。勾選自動錄影後再玩一場。';}$('replay-section').scrollIntoView({behavior:field.reduce?'instant':'smooth'});});
$('photo').addEventListener('click',async()=>{
 try{compose();const photo=await studio.photo((state==='complete'||state==='idle')&&studio.url?$('replay'):null);const a=document.createElement('a');a.href=photo.url;a.download=fileName('photo',photo.blob);const img=document.createElement('img');img.src=photo.url;img.alt='我的動作照片';const caption=document.createElement('small');caption.textContent=`照片 ${++photoCount} · 點擊下載`;a.append(img,caption);$('photos').prepend(a);if($('photos').children.length>12){const old=$('photos').lastChild;URL.revokeObjectURL(old.href);old.remove();}}
 catch{$('record-status').textContent='拍照失敗，請稍後重試。';}
});
$('clip-start').addEventListener('input',()=>updateClip('start'));$('clip-end').addEventListener('input',()=>updateClip('end'));
$('best-clip').addEventListener('click',()=>{const b=studio.bestClip();$('clip-start').value=b.start;$('clip-end').value=b.end;updateClip();});
$('preview-clip').addEventListener('click',async()=>{const b=updateClip();clipPreviewEnd=b.end;$('replay').currentTime=b.start;try{await $('replay').play();}catch{$('record-status').textContent='請按影片播放鍵預覽。';}});
$('replay').addEventListener('timeupdate',()=>{if(clipPreviewEnd!==null&&$('replay').currentTime>=clipPreviewEnd){$('replay').pause();clipPreviewEnd=null;}});
$('replay').addEventListener('seeking',()=>{if(clipPreviewEnd!==null&&$('replay').currentTime>clipPreviewEnd)clipPreviewEnd=null;});
$('export-clip').addEventListener('click',async()=>{
 const b=updateClip();$('replay').pause();$('export-clip').disabled=true;$('start').disabled=true;$('best-clip').disabled=true;
 try{const blob=await studio.exportClip(b.start,b.end,p=>{$('record-status').textContent=`正在截取片段 · ${Math.round(p*100)}%（${(b.end-b.start).toFixed(1)} 秒）`;});if(clipUrl)URL.revokeObjectURL(clipUrl);clipUrl=URL.createObjectURL(blob);$('download-clip').href=clipUrl;$('download-clip').download=fileName('clip',blob);$('download-clip').classList.remove('hidden');$('record-status').textContent=`片段已完成 · ${(b.end-b.start).toFixed(1)} 秒，可下載保存。`;}
 catch(e){$('record-status').textContent='片段截取失敗：'+e.message;}finally{controls();}
});
document.addEventListener('keydown',e=>{if(e.repeat||['SELECT','INPUT','TEXTAREA','VIDEO'].includes(e.target.tagName)||e.target.closest?.('#replay-section')||$('help-dialog').open)return;const p=POSES.find(p=>p.key===e.key);if(p){e.preventDefault();attempt(p.id);}if(e.code==='Space'){e.preventDefault();if(state==='idle'||state==='complete')start();else pause();}if(e.key.toLowerCase()==='f')fullscreen();if(e.key.toLowerCase()==='p'){$('photo').click();e.preventDefault();}});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&state==='running')pause();});window.addEventListener('pagehide',()=>{stopCamera();sound.stop();studio.dispose();if(clipUrl)URL.revokeObjectURL(clipUrl);});
if(!recordingFormat()||!HTMLCanvasElement.prototype.captureStream){$('auto-record').checked=false;$('auto-record').disabled=true;$('record-status').textContent='此瀏覽器不支援錄影，可使用 Chrome。';}
reset();requestAnimationFrame(render);const cameraTicker=setInterval(()=>sendFrame(performance.now()),60);window.addEventListener('pagehide',()=>clearInterval(cameraTicker));
