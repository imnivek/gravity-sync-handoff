#!/usr/bin/env python3
"""Verify this handoff snapshot using only Python's standard library."""
from pathlib import Path
import hashlib
import json
import sys

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'MANIFEST_SHA256.json').read_text(encoding='utf-8'))
errors = []
for entry in manifest['files']:
    path = root / entry['path']
    if not path.is_file():
        errors.append('Missing: ' + entry['path'])
        continue
    content = path.read_bytes()
    if len(content) != entry['bytes'] or hashlib.sha256(content).hexdigest() != entry['sha256']:
        errors.append('Changed: ' + entry['path'])
expected = {entry['path'] for entry in manifest['files']} | {'MANIFEST_SHA256.json'}
for path in root.rglob('*'):
    if path.is_file() and path.name != '.DS_Store' and '__pycache__' not in path.parts and path.suffix != '.pyc':
        relative = path.relative_to(root).as_posix()
        if relative not in expected:
            errors.append('Unexpected: ' + relative)
if errors:
    print('\n'.join(errors))
    sys.exit(1)
print('PASS: %s files match the SHA-256 manifest.' % len(manifest['files']))
